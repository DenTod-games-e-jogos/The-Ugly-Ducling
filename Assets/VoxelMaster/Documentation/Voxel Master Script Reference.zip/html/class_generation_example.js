var class_generation_example =
[
    [ "Generation", "class_generation_example.html#a3d494a324f7994066da437741d9de731", null ]
];