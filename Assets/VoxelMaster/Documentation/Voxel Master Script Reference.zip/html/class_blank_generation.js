var class_blank_generation =
[
    [ "Generation", "class_blank_generation.html#a5c4a8b638dd8cdd04e6a05030feb14a7", null ]
];