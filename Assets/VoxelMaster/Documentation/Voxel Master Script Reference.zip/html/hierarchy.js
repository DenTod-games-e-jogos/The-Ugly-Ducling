var hierarchy =
[
    [ "VoxelMaster.Block", "class_voxel_master_1_1_block.html", null ],
    [ "VoxelMaster.BlockTexture", "class_voxel_master_1_1_block_texture.html", null ],
    [ "VoxelMaster.Chunk", "class_voxel_master_1_1_chunk.html", null ],
    [ "Editor", null, [
      [ "VoxelMaster.BlockInfoEditor", "class_voxel_master_1_1_block_info_editor.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "HelperExample", "class_helper_example.html", null ],
      [ "LoadingExample", "class_loading_example.html", null ],
      [ "ShapesExample", "class_shapes_example.html", null ],
      [ "VoxelMaster.BaseGeneration", "class_voxel_master_1_1_base_generation.html", [
        [ "BlankGeneration", "class_blank_generation.html", null ],
        [ "GenerationExample", "class_generation_example.html", null ]
      ] ],
      [ "VoxelMaster.BasicCamera", "class_voxel_master_1_1_basic_camera.html", null ],
      [ "VoxelMaster.ChunkManager", "class_voxel_master_1_1_chunk_manager.html", null ],
      [ "VoxelMaster.VoxelGeneration", "class_voxel_master_1_1_voxel_generation.html", null ],
      [ "VoxelMaster.VoxelTerrain", "class_voxel_master_1_1_voxel_terrain.html", null ]
    ] ],
    [ "ScriptableObject", null, [
      [ "VoxelMaster.BlockDictionary", "class_voxel_master_1_1_block_dictionary.html", null ],
      [ "VoxelMaster.BlockInfo", "class_voxel_master_1_1_block_info.html", null ]
    ] ]
];