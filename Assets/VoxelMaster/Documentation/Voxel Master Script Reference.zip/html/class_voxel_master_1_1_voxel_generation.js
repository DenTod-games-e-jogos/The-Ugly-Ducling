var class_voxel_master_1_1_voxel_generation =
[
    [ "GenerationAction", "class_voxel_master_1_1_voxel_generation.html#af9b9d6083dd5259e613def70dec63f92", null ],
    [ "SetGenerationAction", "class_voxel_master_1_1_voxel_generation.html#a5c77432d7d80dbff4db689fd05fad030", null ],
    [ "camera", "class_voxel_master_1_1_voxel_generation.html#a4608bd2bd3ae6c964dcd1d6f21999875", null ],
    [ "chunksPerFrame", "class_voxel_master_1_1_voxel_generation.html#af6a85ea271c0844652c1ebcf761e78b4", null ],
    [ "destroyUnusedChunks", "class_voxel_master_1_1_voxel_generation.html#a85468a9b3b2f7543285f7ffdad0ceffc", null ],
    [ "generationDistance", "class_voxel_master_1_1_voxel_generation.html#a3c7618ef04674905c5f11872cf378827", null ],
    [ "updateDistance", "class_voxel_master_1_1_voxel_generation.html#ab3de035995b6c57c8ae92e7c6e7d6d9c", null ]
];