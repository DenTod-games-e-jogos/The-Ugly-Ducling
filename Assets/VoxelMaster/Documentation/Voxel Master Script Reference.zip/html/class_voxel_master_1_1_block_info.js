var class_voxel_master_1_1_block_info =
[
    [ "blockName", "class_voxel_master_1_1_block_info.html#a68c1a6629ee27df90417b38907128b15", null ],
    [ "blockTexture", "class_voxel_master_1_1_block_info.html#a73e7304a11c1bc816fa3b111d2218263", null ],
    [ "durability", "class_voxel_master_1_1_block_info.html#a04ab5c773e81252a20bb69c4b2b1a3d8", null ],
    [ "id", "class_voxel_master_1_1_block_info.html#a7880937628e45cd0d00e51b4aebb40f9", null ],
    [ "transparent", "class_voxel_master_1_1_block_info.html#a0a8ee118bb86eb97cf35b2c25edfbfdb", null ]
];