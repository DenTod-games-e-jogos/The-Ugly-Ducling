var class_voxel_master_1_1_chunk =
[
    [ "Chunk", "class_voxel_master_1_1_chunk.html#a97fd5b46abc7f4ab90ebe48e3f1981c4", null ],
    [ "Clear", "class_voxel_master_1_1_chunk.html#adceb5b88b9abef77257ca7f4ed20d55c", null ],
    [ "Delete", "class_voxel_master_1_1_chunk.html#a98f63a6efa8f9d1b4c03b296c8855d8f", null ],
    [ "FastRefresh", "class_voxel_master_1_1_chunk.html#a98148865469130dfccd7ccaaac818587", null ],
    [ "GetBlock", "class_voxel_master_1_1_chunk.html#a230fb9dff076bad93d641222989bb699", null ],
    [ "GetBlockID", "class_voxel_master_1_1_chunk.html#ab8e0978c72f712d89520ad83b4d91aaf", null ],
    [ "Refresh", "class_voxel_master_1_1_chunk.html#af3427c69f836e9e00e3f96c2d9e9793a", null ],
    [ "SetBlockID", "class_voxel_master_1_1_chunk.html#a1fae4b7f47bf1dfea2412b6f743b8979", null ],
    [ "SetBlocks", "class_voxel_master_1_1_chunk.html#a0a3ca2d24d54834b58383ef9da3c89fa", null ],
    [ "count", "class_voxel_master_1_1_chunk.html#a8540428811268e14ef73fd4e3424a602", null ],
    [ "dirty", "class_voxel_master_1_1_chunk.html#a54fa7bb8201c92e5c04b361dd5a899b1", null ],
    [ "gameObject", "class_voxel_master_1_1_chunk.html#a54163e093d8ccb437648cf8ea733baa1", null ],
    [ "id", "class_voxel_master_1_1_chunk.html#a2bc46f326e3b2653afac20d33b2f4d1d", null ],
    [ "needsBatching", "class_voxel_master_1_1_chunk.html#afb2b7e85cc8af5cdbe0e3386c399384e", null ],
    [ "parent", "class_voxel_master_1_1_chunk.html#a30a0330d168186286e9531a393e0c787", null ],
    [ "pos", "class_voxel_master_1_1_chunk.html#a0bde962354b09e5f63191619dcd37346", null ],
    [ "size", "class_voxel_master_1_1_chunk.html#a98a0e4cd712196f5fa0938b5bd2e7d5d", null ],
    [ "visible", "class_voxel_master_1_1_chunk.html#ae7738302ead07cfb97709942f726d77b", null ],
    [ "x", "class_voxel_master_1_1_chunk.html#a7c0b12cbdf2d41f1de8e5ae5302a3ff4", null ],
    [ "y", "class_voxel_master_1_1_chunk.html#ad98acb80f0400aad85bfa441ba79255f", null ],
    [ "z", "class_voxel_master_1_1_chunk.html#ac7b91b7f91324cfc41d60d71a90929b9", null ]
];