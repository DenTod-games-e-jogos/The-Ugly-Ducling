var searchData=
[
  ['batchdirty',['batchDirty',['../class_voxel_master_1_1_voxel_terrain.html#a95d15e5bb557d578947578f3bffbe8fe',1,'VoxelMaster::VoxelTerrain']]],
  ['blockinfo',['blockInfo',['../class_voxel_master_1_1_block.html#ab02d19dd4d9ef1042fda6613694ddefa',1,'VoxelMaster::Block']]]
];
