var searchData=
[
  ['needsbatching',['needsBatching',['../class_voxel_master_1_1_chunk.html#afb2b7e85cc8af5cdbe0e3386c399384e',1,'VoxelMaster::Chunk']]]
];
