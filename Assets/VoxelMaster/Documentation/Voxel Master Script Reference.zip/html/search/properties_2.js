var searchData=
[
  ['dirty',['dirty',['../class_voxel_master_1_1_chunk.html#a54fa7bb8201c92e5c04b361dd5a899b1',1,'VoxelMaster.Chunk.dirty()'],['../class_voxel_master_1_1_voxel_terrain.html#a631d02ce278a66b4122b0ffa4f8bade6',1,'VoxelMaster.VoxelTerrain.dirty()']]]
];
