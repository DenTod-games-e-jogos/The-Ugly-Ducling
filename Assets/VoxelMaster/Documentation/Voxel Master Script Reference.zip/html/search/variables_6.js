var searchData=
[
  ['id',['id',['../class_voxel_master_1_1_block_info.html#a7880937628e45cd0d00e51b4aebb40f9',1,'VoxelMaster::BlockInfo']]],
  ['ignoreyaxis',['ignoreYAxis',['../class_voxel_master_1_1_voxel_terrain.html#a452caae90f4ceb4a70c961bc806dcf55',1,'VoxelMaster::VoxelTerrain']]]
];
