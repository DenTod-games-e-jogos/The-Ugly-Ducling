var searchData=
[
  ['isblockceiling',['IsBlockCeiling',['../class_voxel_master_1_1_voxel_terrain.html#a8175b31c11fb5401ce75f55220d551b2',1,'VoxelMaster.VoxelTerrain.IsBlockCeiling(int x, int y, int z)'],['../class_voxel_master_1_1_voxel_terrain.html#a9290404abcf771e7f69f81216d2ed713',1,'VoxelMaster.VoxelTerrain.IsBlockCeiling(Vector3 pos)']]],
  ['isblockground',['IsBlockGround',['../class_voxel_master_1_1_voxel_terrain.html#addb8d3cf1a47602d327643da83f64995',1,'VoxelMaster.VoxelTerrain.IsBlockGround(int x, int y, int z)'],['../class_voxel_master_1_1_voxel_terrain.html#a6359ffb8da5224a7fee61c641d4d23a3',1,'VoxelMaster.VoxelTerrain.IsBlockGround(Vector3 pos)']]],
  ['isblockvisible',['IsBlockVisible',['../class_voxel_master_1_1_voxel_terrain.html#a9a870422060805b63362440abc7d15a4',1,'VoxelMaster.VoxelTerrain.IsBlockVisible(int x, int y, int z)'],['../class_voxel_master_1_1_voxel_terrain.html#ab2671d0c578445b93679ecff2c79d643',1,'VoxelMaster.VoxelTerrain.IsBlockVisible(Vector3 pos)']]],
  ['isblockwall',['IsBlockWall',['../class_voxel_master_1_1_voxel_terrain.html#a0ba6bdb8d8bdc811fcc08d40c86bc6cd',1,'VoxelMaster.VoxelTerrain.IsBlockWall(int x, int y, int z)'],['../class_voxel_master_1_1_voxel_terrain.html#addce9e920785e88404c0bd0bfd595372',1,'VoxelMaster.VoxelTerrain.IsBlockWall(Vector3 pos)']]]
];
