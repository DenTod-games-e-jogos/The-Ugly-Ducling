var indexSectionsWithContent =
{
  0: "bcdefghilmnprstuvwxyz",
  1: "bcghlsv",
  2: "v",
  3: "bcdfgilrstw",
  4: "bcdefgilmprstu",
  5: "bcdginpsvxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Properties"
};

