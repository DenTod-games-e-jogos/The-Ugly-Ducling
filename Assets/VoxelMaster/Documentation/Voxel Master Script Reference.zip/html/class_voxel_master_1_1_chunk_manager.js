var class_voxel_master_1_1_chunk_manager =
[
    [ "destroyUnused", "class_voxel_master_1_1_chunk_manager.html#a64d3913fdafff56ce9575af27388381c", null ],
    [ "dirty", "class_voxel_master_1_1_chunk_manager.html#aa588bc00d3c8b0114b67d49d8ee1a7bb", null ],
    [ "parent", "class_voxel_master_1_1_chunk_manager.html#ac623f4c718cdfd1208ce76dd06f1efc9", null ],
    [ "updateRate", "class_voxel_master_1_1_chunk_manager.html#a3d3935cf3819e9be12b6d56272c36d40", null ],
    [ "centeredPosition", "class_voxel_master_1_1_chunk_manager.html#a866bcfc92b3d8629ca3d565949ace137", null ]
];