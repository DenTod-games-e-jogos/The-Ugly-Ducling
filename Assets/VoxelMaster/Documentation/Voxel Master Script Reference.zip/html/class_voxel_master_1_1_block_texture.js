var class_voxel_master_1_1_block_texture =
[
    [ "back", "class_voxel_master_1_1_block_texture.html#a605287212f4449e6eca7557a0ebe5362", null ],
    [ "bottom", "class_voxel_master_1_1_block_texture.html#a9f4118c95a70afa82acfd3deb929e289", null ],
    [ "front", "class_voxel_master_1_1_block_texture.html#a2f213f79c1c15bf9ae11f09d9c26379b", null ],
    [ "left", "class_voxel_master_1_1_block_texture.html#aeb03d3c181ca60af0a66253720075776", null ],
    [ "right", "class_voxel_master_1_1_block_texture.html#a02c261746accdbd4f22118500882b8e4", null ],
    [ "top", "class_voxel_master_1_1_block_texture.html#a0b9d7fde6cabdb8e4c8184df4f51dd70", null ]
];